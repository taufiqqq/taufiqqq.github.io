# drawio-i18n

This repo is auto-generated from the i18n spreadsheet https://docs.google.com/spreadsheets/d/1FoYdyEraEQuWofzbYCDPKN7EdKgS_2ZrsDrOA8scgwQ/edit#gid=0

The repo is part of the JGraph SOC 2 process. All changes are reviewed when the sub-module is updated in drawio-dev.
